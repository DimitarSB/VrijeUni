#ifndef WEBSERVER_INTERCEPT_H
#define WEBSERVER_INTERCEPT_H

void spawn_log_thread();
#endif
