// DO NOT MODIFY FOR BASIC SUBMISSION
// scalastyle:off

package engine.graphics

case class Triangle(p1: Point, p2: Point, p3: Point)
