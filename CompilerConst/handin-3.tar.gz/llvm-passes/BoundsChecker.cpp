#define DEBUG_TYPE "BoundsChecker"
#include "utils.h"
#include "llvm/IR/InstIterator.h"
#include "llvm/IR/IRBuilder.h"

namespace {
    class BoundsChecker : public ModulePass {
    public:
        static char ID;
        BoundsChecker() : ModulePass(ID) {}
        virtual bool runOnModule(Module &M) override;

    private:
        Function *CheckFunc;
        bool allZero(GetElementPtrInst *GEP);
        bool processGEPs(Function &F);
        //void HandleSubGEPs(GetElementPtrInst *GEP, IRBuilder<> &B);
        //Value* recursivePointer(GetElementPtrInst *GEP);
        Value* sumOffsets(GetElementPtrInst *GEP, IRBuilder<> &B);
        Value* gepOrigin(GetElementPtrInst *GEP, IRBuilder<> &B);
    };
}

bool BoundsChecker::processGEPs(Function &F) {
    LOG_LINE("START OF processGEPs");
    bool Changed = false;

    IRBuilder<> B(&F.getEntryBlock());

    for (Instruction &II : instructions(F)) {
        Instruction *I = &II;
        LOG_LINE("Instruction:");
        I->dump();

        if (GetElementPtrInst *GEP = dyn_cast<GetElementPtrInst>(I)) {
            Value *offset = sumOffsets(GEP, B);
            LOG_LINE("processGEPs - Offset variable");
            offset->dump();
            Value *range = gepOrigin(GEP, B);
            LOG_LINE("processGEPs - Range variable:");
            if (range==nullptr) {
                LOG_LINE("Range Nullpointer");
            }
            else {
                range->dump();
                B.SetInsertPoint(GEP);  //Insert c function before GEP
                B.CreateCall(CheckFunc, { offset, range });
                Changed = true;
            }
        }
    }
    return Changed;
}

bool BoundsChecker::allZero(GetElementPtrInst *GEP) {

    for (unsigned i = 1; i < GEP->getNumOperands(); i++) {
        Value *op = GEP->getOperand(i);
        if (ConstantInt *CI = dyn_cast<ConstantInt>(op)) {
            if (!CI->isZero())
                return false;
            }
    }
    return true;
}

Value* BoundsChecker::sumOffsets(GetElementPtrInst *GEP, IRBuilder<> &B) {

    /*if (GEP->getNumOperands() != 1 || allZero(GEP) == false){
        return 0;
    }*/
    if (GEP->getNumOperands() != 1){
        LOG_LINE("sumOffsets - Multiple GEP operands: " << GEP->getNumOperands());
    }
    if (allZero(GEP) == false){
        LOG_LINE("sumOffsets - Not an all-zero GEP.");
    }

    Value *offset = GEP->getOperand(1);

    GetElementPtrInst *parentPointer = dyn_cast<GetElementPtrInst>(GEP->getOperand(0));
    if (parentPointer) {
        return B.CreateAdd(offset, sumOffsets(parentPointer, B));
    }
    else return offset;

}

Value* BoundsChecker::gepOrigin(GetElementPtrInst *GEP, IRBuilder<> &B) {
    LOG_LINE("START OF gepOrigin");

    if (AllocaInst *alloca = dyn_cast<AllocaInst>(GEP->getOperand(0))) {
        LOG_LINE("gepOrigin test marker - AllocaInst");
        return alloca->getArraySize();
    }
    else if (Argument *arg = dyn_cast<Argument>(GEP->getOperand(0))) {
        LOG_LINE("gepOrigin test marker - Argument 1");
        if (arg->getParent()->getName() == "main") {
            LOG_LINE("gepOrigin test marker - Argument 2");
            if (arg->getArgNo() > 1) {
                LOG_LINE("gepOrigin test marker - Argument 3");
                Value *argc = arg->getParent()->getArg(1);
                Value *argv = B.CreateAdd(argc, ConstantInt::get(argc->getType(), 1));
                return argv;
            }
        }
    }
    else if (Constant *cons = dyn_cast<Constant>(GEP->getOperand(0))) {
        LOG_LINE("gepOrigin test marker - Constant");
        if (cons->getType()->isArrayTy()) {
            ConstantDataSequential *dataArray = cast<ConstantDataSequential>(cons);
            return ConstantInt::get(cons->getType()->getArrayElementType(), dataArray->getNumElements());
        }
    }
    else if (GetElementPtrInst *GEPInst = dyn_cast<GetElementPtrInst>(GEP->getOperand(0))) {
        LOG_LINE("gepOrigin test marker - GetElementPtrInst");
        return gepOrigin(GEPInst, B);
    }
    return nullptr;
}

bool BoundsChecker::runOnModule(Module &M) {
    
    // Retrieve a pointer to the helper function. The instrumentAllocations
    // function will insert calls to this function for every allocation. This
    // function is written in our runtime (runtime/dummy.c). To see its (LLVM)
    // type, you can check runtime/obj/dummy.ll)
    LLVMContext &C = M.getContext();
    Type *VoidTy = Type::getVoidTy(C);
    Type *Int32Ty = Type::getInt32Ty(C);

    auto FnCallee = M.getOrInsertFunction("__coco_check_bounds", VoidTy, Int32Ty, Int32Ty);
    CheckFunc = cast<Function>(FnCallee.getCallee());

    // LLVM wants to know whether we made any modifications to the IR, so we
    // keep track of this.
    bool Changed = false;

    for (Function &F : M) {
        // We want to skip instrumenting certain functions, like declarations
        // and helper functions (e.g., our dummy_print_allocation)
        if (!shouldInstrument(&F))
            continue;

        LOG_LINE("Visiting function " << F.getName());
        
        if (processGEPs(F)) {
            Changed = true;
        }
    }

    return Changed;
}

char BoundsChecker::ID = 0;
static RegisterPass<BoundsChecker> X("coco-boundscheck", "Example LLVM module pass that inserts prints for GEP instructions.");
