#include <stdio.h>
#include <stdlib.h>

void __coco_check_bounds(int wishedSpace, int totalSpace) {
    if(wishedSpace > totalSpace || wishedSpace < 0){
        printf("Vector at possition %d not allowed\n", wishedSpace);
        printf("Total positions: %d\n", totalSpace); 
        exit(1);
    }

}