/*
 * Casts an integer into a float, since the language itself does not support
 * casting operation. Note: In our language a float is double precision, i.e., a
 * double in C.
 */
double int_to_float(int i) {
    return  1. * i;
}
