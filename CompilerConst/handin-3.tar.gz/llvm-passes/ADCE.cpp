#define DEBUG_TYPE "ADCE"
#include "utils.h"
#include "llvm/ADT/DenseSet.h"
#include "llvm/ADT/DepthFirstIterator.h"

namespace {
    class ADCE : public FunctionPass {
    public:
        static char ID;
        ADCE() : FunctionPass(ID) {}

        virtual bool runOnFunction(Function &F) override;

    };
}

bool ADCE::runOnFunction(Function &F) {
    DenseSet<Instruction *> liveList;
    DenseSet<Instruction *> deadList;

    df_iterator_default_set<BasicBlock*> reachableBlocks;
    for (BasicBlock *BB : depth_first_ext(&F, reachableBlocks)) {
        for (Instruction &II : *BB) {
            Instruction *I = &II;

            if (LoadInst *AI = dyn_cast<LoadInst>(I)) {
                if(AI->isVolatile()){
                  liveList.insert(I);  
                }
            }
            else if (I->mayHaveSideEffects() || I->isTerminator() || I->mayWriteToMemory() || isa<CallInst>(I)) {
                liveList.insert(I);
            } else if (I->use_empty()) {
                deadList.insert(I);
            }
        }
    }
    //_________________________
    
        SmallVector<Instruction *, 111> workList(liveList.begin(), liveList.end());

        while (!workList.empty()) {
            Instruction *I = workList.pop_back_val();
            BasicBlock *BB = I->getParent();
            if (reachableBlocks.count(BB) > 0) {
                for (Value *O : I->operands()) {
                    if (Instruction *OperandI = dyn_cast<Instruction>(O)) {
                        if (liveList.count(OperandI) == 0) {
                            workList.push_back(OperandI);
                            liveList.insert(OperandI);
                            
                        }
                    }
                }
            }
        }

        for(BasicBlock &BB : F){
            if(reachableBlocks.count(&BB) > 0){
                for(Instruction &II : BB){
                    Instruction *I = &II;
                    if(!liveList.count(I)){
                        I->dropAllReferences();
                    }
                }
            }
        }

        for(BasicBlock &BB : F){
            if(reachableBlocks.count(&BB) > 0){
                for(Instruction &II : BB){
                    Instruction *I = &II;
                    if(!liveList.count(I)){
                        deadList.insert(I);
                    }
                }
            }
        }

        for (Instruction *DeadI : deadList) {
            DeadI->eraseFromParent();
        }
        
    return true;  // We have modified the IR
}

char ADCE::ID = 0;
static RegisterPass<ADCE> X("coco-adce", "Aggressive Dead Code Elimination Pass");