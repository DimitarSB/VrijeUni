#define DEBUG_TYPE "ConstPropPass"
#include "utils.h"

namespace {
    class ConstProp : public FunctionPass {
    public:
        static char ID;
        ConstProp() : FunctionPass(ID) {}
        virtual bool runOnFunction(Function &F) override;
    };
}

bool ConstProp::runOnFunction(Function &F) {
    LOG_LINE("Visiting function " << F.getName());
//    DenseSet<Instruction*> modI;
    for (BasicBlock &BB : F) {
        for (Instruction &II : BB) {
            Instruction *I = &II;
            if (BinaryOperator *BO = dyn_cast<BinaryOperator>(I)) {
                // Are they const:
                APInt result;
                
                if (ConstantInt *constInt1 = dyn_cast<ConstantInt>(BO->getOperand(0))) {
                    if (ConstantInt *constInt2 = dyn_cast<ConstantInt>(BO->getOperand(1))) {
                        switch (BO->getOpcode()) {
                            case Instruction::Add:
                                result = constInt1->getValue() + constInt2->getValue();
                                break;
                            case Instruction::Sub:
                                result = constInt1->getValue() - constInt2->getValue();
                                break;
                            case Instruction::Mul:
                                result = constInt1->getValue() * constInt2->getValue();
                                break;
                            case Instruction::Shl:
                                result = constInt1->getValue() << constInt2->getValue().getLimitedValue();
                                break;
                            case Instruction::LShr:
                                result = constInt1->getValue().lshr(constInt2->getValue().getLimitedValue());
                                break;
                            case Instruction::AShr:
                                result = constInt1->getValue().ashr(constInt2->getValue().getLimitedValue());
                                break;
                            case Instruction::And:
                                result = constInt1->getValue() & constInt2->getValue();
                                break;
                            case Instruction::Or:
                                result = constInt1->getValue() | constInt2->getValue();
                                break;
                            case Instruction::Xor:
                                result = constInt1->getValue() ^ constInt2->getValue();
                                break;
                            default:
                                LOG_LINE("Something is not a int!");
                                break;
                        }

                        ConstantInt *replacement = ConstantInt::get(I->getType()->getContext(), result);
                        I->replaceAllUsesWith(replacement);
                    }
                }
                else if (ConstantFP *constFloat1 = dyn_cast<ConstantFP>(BO->getOperand(0))) {
                        if (ConstantFP *constFloat2 = dyn_cast<ConstantFP>(BO->getOperand(1))) {
                            APFloat resultFloat(constFloat1->getValueAPF().getSemantics()); 
                            switch (BO->getOpcode()) {
                                case Instruction::FAdd:
                                    resultFloat = constFloat1->getValueAPF() + constFloat2->getValueAPF();
                                    break;
                                case Instruction::FSub:
                                    resultFloat = constFloat1->getValueAPF() - constFloat2->getValueAPF();
                                    break;
                                case Instruction::FMul:
                                    resultFloat = constFloat1->getValueAPF() * constFloat2->getValueAPF();
                                    break;
                                case Instruction::FDiv:
                                    if(constFloat2->isZero()){
                                        LOG_LINE("Divition by 0!");
                                        return -1;
                                    }
                                    resultFloat = constFloat1->getValueAPF() / constFloat2->getValueAPF();
                                    break;                                  
                                default:
                                    LOG_LINE("Something is not a float!");
                                    break;
                            }

                            ConstantFP *replacement = ConstantFP::get(I->getType()->getContext(), resultFloat);
                            I->replaceAllUsesWith(replacement);
                        }
                }
            }
        }
    }
    return true;
}

// Register the pass with LLVM
char ConstProp::ID = 0;
static RegisterPass<ConstProp> X("coco-constprop", "Constant Propagation Pass");