#define DEBUG_TYPE "LICM"
#include "utils.h"
#include <vector>

namespace {
    class LICM : public LoopPass {
    public:
        static char ID;
        LICM() : LoopPass(ID) {}
        virtual bool runOnLoop(Loop *L, LPPassManager &LPM) override;
        void getAnalysisUsage(AnalysisUsage &AU) const override;
    };
}

void LICM::getAnalysisUsage(AnalysisUsage &AU) const {
    // Tell LLVM we need some analysis info which we use for analyzing the DominatorTree.
    AU.setPreservesCFG();
    AU.addRequired<LoopInfoWrapperPass>();
    getLoopAnalysisUsage(AU);
}

bool isInvariant(Instruction *I) {
    return (I->isBinaryOp() || I->isShift() || isa<SelectInst>(I) || I->isCast() || isa<GetElementPtrInst>(I));
}

bool hasLoopInvariantOperandsCustom(Instruction *I, Loop *L) {
    for (Value *V : I->operands()) {
        if (Instruction *J = dyn_cast<Instruction>(V)) {
            return !L->contains(J->getParent());
        }
    }
    return true;
}

bool hasInvariantOperands(Instruction *I, Loop *L) {
    if ((I->getNumOperands()) > 0) {
        for (int i=0; i<(int) I->getNumOperands(); i++) { // loop through operands of the instruction
            if ((!isa<Constant>(I->getOperand(i))) && (!hasLoopInvariantOperandsCustom(I, L))) {
                return false;
            }
        }
    }
    return true;
}

bool LICM::runOnLoop(Loop *L, LPPassManager &LPM) {
    BasicBlock *Header = L->getHeader();
    DominatorTree *DT = &getAnalysis<DominatorTreeWrapperPass>().getDomTree();
    bool returnValue = false;

    for (BasicBlock *BB : L->blocks()) {
        if (DT->dominates(Header, BB)) {
            std::vector<Instruction*> instructionYeetList = {};
            for (BasicBlock::iterator i = BB->begin(); i != BB->end(); i++) {
                if (isa<Instruction>(&*i)) {
                    Instruction *I = dyn_cast<Instruction>(i);
                    if (isInvariant(I) && hasInvariantOperands(I, L)) {
                        returnValue = true;
                        instructionYeetList.push_back(I);
                    }
                }
            }
            //LOG_LINE("Mover counter: " << instructionYeetList.size());
            for (Instruction* I : instructionYeetList) {
                //LOG_LINE("Mover? I hardly know her!: " << I);
                I->moveBefore(L->getLoopPreheader()->getTerminator());
            }
        }
    }

    return returnValue;
}

char LICM::ID = 0;
RegisterPass<LICM> X("coco-licm", "CoCo Dominator Tree");
