#include <semaphore.h>
#include <assert.h>

#include "server_utils.h"
#include "common.h"
#include "request_dispatcher.h"
#include "hash.h"
#include "kvstore.h"

// DO NOT MODIFY THIS.
// ./check.py assumes the hashtable has 256 buckets.
// You should initialize your hashtable with this capacity.
#define HT_CAPACITY 256

int set_request(int socket, struct request *request)
{
    size_t len = 0;
    size_t expected_len = request->msg_len;

    // 1. Get entry or create one if it does not exist.
    // Note: take into account critical regions.
    // Another thread entering this function should not be able to get the entry again.

    while (len < expected_len) {
        // 2. Read the payload from the socket
        // Note: Clients may send a partial chunk of the payload: do not not wait
        // for the full data to be available before writing in the hashtable entry.

        // 3. Write the partial payload on the entry
    }

    // 4. Insert the entry in the store.
    // This allow other threads to read the entry.

    // It checks if the payload has been fully received .
    // It also reads the last char of the request which should be '\n'
    check_payload(socket, request, expected_len);
    send_response(socket, OK, 0, NULL);

    // pr_info("Read %zu / %zu\n", len, expected_len);

    // Optionally you can close the connection
    // You should do it ONLY on errors:
    // request->connection_close = 1;
    return len;
}

void *main_job(void *arg)
{
    int method;
    struct conn_info *conn_info = arg;
    struct request *request = allocate_request();
    request->connection_close = 0;

    pr_info("Starting new session from %s:%d\n",
        inet_ntoa(conn_info->addr.sin_addr),
        ntohs(conn_info->addr.sin_port));

    do {
        method = recv_request(conn_info->socket_fd, request);
        // Insert your operations here
        switch (method) {
        case SET:
            set_request(conn_info->socket_fd, request);
            break;
        case GET:
            break;
        case DEL:
            break;
        case RST:
            // ./check.py issues a reset request after each test
            // to bring back the hashtable to a known state.
            // Implement your reset command here.
            send_response(conn_info->socket_fd, OK, 0, NULL);
            break;
        case STAT:
            break;
        }

        if (request->key) {
            free(request->key);
        }

    } while (!request->connection_close);

    close_connection(conn_info->socket_fd);
    free(request);
    free(conn_info);
    return (void *)NULL;
}

int main(int argc, char *argv[])
{
    int listen_sock;

    listen_sock = server_init(argc, argv);

    // Initialize your hashtable.
    // @see kvstore.h for hashtable struct declaration

    for (;;) {
        struct conn_info *conn_info =
            calloc(1, sizeof(struct conn_info));
        if (accept_new_connection(listen_sock, conn_info) < 0) {
            error("Cannot accept new connection");
            free(conn_info);
            continue;
        }
        main_job(conn_info);
    }

    return 0;
}
