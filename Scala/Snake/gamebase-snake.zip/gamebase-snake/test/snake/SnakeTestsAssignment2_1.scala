package snake

import org.junit.runner.RunWith
import org.scalatestplus.junit.JUnitRunner
import snake.basic.NoReverseTest

@RunWith(classOf[JUnitRunner])
class SnakeTestsAssignment2_1 extends SnakeTestSuite(  new NoReverseTest){

}
